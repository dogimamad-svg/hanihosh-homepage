import bpy, math, os, sys, json, struct
from mathutils import Vector
from math import pi,sin,cos
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
# Original HaniHoosh mechanical mascot: all geometry generated here; no photo textures.
def mat(name,color,metal=0,rough=.3,emit=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emit:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emit
 return m
shell=mat('Obsidian titanium',(.055,.075,.13),.88,.24);chrome=mat('Brushed platinum',(.43,.52,.65),.94,.23);dark=mat('Carbon joints',(.012,.019,.035),.5,.38);glass=mat('Midnight visor',(.009,.025,.045),.74,.16)
blue=mat('Ion blue',(.018,.20,1),.5,.25,2.8);mint=mat('Cognitive mint',(.025,.85,.72),.25,.2,2.5);violet=mat('Violet circuits',(.35,.025,.9),.45,.25,2);gold=mat('Champagne accents',(.9,.55,.18),.85,.26)
objects=[]
def finish(o,name,m,bone='Head',bevel=0):
 o.name=name;o.data.materials.append(m)
 if bevel:
  mod=o.modifiers.new('Manufactured edge','BEVEL');mod.width=bevel;mod.segments=3
 for p in o.data.polygons:p.use_smooth=True
 objects.append((o,bone));return o

def sphere(name,loc,scale,m,bone='Head'):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,bone)
def cube(name,loc,scale,m,bone='Head',bev=.06):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,m,bone,bev)
def torus(name,loc,r,t,m,rot=(pi/2,0,0),bone='Head'):
 bpy.ops.mesh.primitive_torus_add(major_segments=48,minor_segments=10,location=loc,major_radius=r,minor_radius=t,rotation=rot);return finish(bpy.context.object,name,m,bone)
def cylinder(name,loc,r,depth,m,rot=(0,0,0),bone='Head'):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=depth,location=loc,rotation=rot);return finish(bpy.context.object,name,m,bone,.015)
def line(name,points,r,m,bone='Head'):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=2;c.bevel_depth=r;c.bevel_resolution=3;s=c.splines.new('POLY');s.points.add(len(points)-1)
 for v,p in zip(s.points,points):v.co=(*p,1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object;o.select_set(False);return finish(o,name,m,bone)
def badge(name,loc,size,m,bone='Head'):
 c=bpy.data.curves.new(name,'FONT');c.body='H';c.align_x='CENTER';c.size=size;c.extrude=.008;c.bevel_depth=.002;o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(pi/2,0,0);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object;o.select_set(False);return finish(o,name,m,bone)
# Mechanical bust, joints and plated shoulders.
sphere('Sternum',(0,0,1.01),(.65,.39,.63),shell,'Root')
sphere('Shoulder bridge',(0,0,1.51),(.99,.42,.28),shell,'Root')
for side in [-1,1]:
 sphere('Shoulder joint',(side*.82,0,1.42),(.26,.29,.26),dark,'Root')
 sphere('Shoulder plating',(side*.91,-.015,1.47),(.32,.34,.22),chrome,'Root')
 line('Shoulder luminous seam',[(side*(.56+i*.035),-.27,1.57-.1*(i/12)**2) for i in range(13)],.017,blue if side<0 else violet,'Root')
 cube('Upper arm',(side*1.02,.04,1.04),(.29,.37,.56),shell,'Root',.12)
 line('Chest seam',[(side*.16,-.395,1.32),(side*.43,-.34,1.24),(side*.53,-.26,.91)],.013,blue if side<0 else violet,'Root')
 cylinder('Collar connector',(side*.32,-.13,1.72),.055,.28,chrome,bone='Root')
cylinder('Neck piston',(0,0,1.91),.21,.53,dark,bone='Root')
for z in [1.73,1.85,1.98,2.07]:torus('Neck bearing',(0,0,z),.225,.038,chrome,rot=(0,0,0),bone='Root')
torus('Collar light',(0,0,1.65),.32,.019,mint,rot=(0,0,0),bone='Root')
cylinder('Chest reactor',(0,-.396,1.13),.205,.05,dark,rot=(pi/2,0,0),bone='Root');torus('Reactor ring',(0,-.433,1.13),.173,.021,blue,bone='Root');badge('Chest insignia',(0,-.46,1.04),.25,mint,'Root')
# Full, closed volumetric head and raised face shell.
sphere('Cranium',(0,0,2.88),(.75,.58,.87),shell)
sphere('Face surround',(0,-.36,2.85),(.69,.31,.69),chrome)
sphere('Face glass',(0,-.505,2.88),(.625,.205,.608),glass)
# Crown and chin are separate manufactured parts.
line('Crown ion rail',[(-.44+i*.88/30,-.26,3.52+.10*sin(i/30*pi)) for i in range(31)],.027,blue)
line('Jaw contour',[(-.46+i*.92/30,-.505,2.38-.13*sin(i/30*pi)) for i in range(31)],.025,chrome)
for side in [-1,1]:
 # Side ear actuator with concentric real torus geometry.
 cylinder('Temple actuator',(side*.745,.0,2.92),.335,.12,dark,rot=(0,pi/2,0))
 torus('Temple chrome ring',(side*.817,0,2.92),.282,.044,chrome,rot=(0,pi/2,0))
 torus('Temple light ring',(side*.854,0,2.92),.223,.016,blue if side<0 else violet,rot=(0,pi/2,0))
 cylinder('Temple cap',(side*.84,0,2.92),.175,.048,shell,rot=(0,pi/2,0))
 for k in range(6):
  angle=2*pi*k/6;sphere('Bearing screw',(side*.863,.27*cos(angle),2.92+.27*sin(angle)),(.022,.022,.022),gold)
 for k in range(3):
  z=2.49+k*.10;line('Cheek gill',[(side*.51,-.54,z),(side*.61,-.41,z+.035)],.018,blue if side<0 else violet)
 # Eyeball assemblies are attached to separate bones.
 bone='Eye_L' if side<0 else 'Eye_R';x=side*.265
 sphere('Eye socket',(x,-.672,3.015),(.214,.067,.165),dark)
 sphere('Eye lens',(x,-.721,3.015),(.163,.072,.125),chrome,bone)
 eye=sphere('Iris',(x,-.785,3.015),(.102,.027,.099),mint if side<0 else blue,bone)
 pupil=sphere('Pupil',(x,-.81,3.015),(.040,.015,.057),dark,bone)
 highlight=sphere('Eye highlight',(x-.028,-.823,3.045),(.016,.008,.016),mint,bone)
 for part in [eye,pupil,highlight]:
  part.shape_key_add(name='Basis');blink=part.shape_key_add(name='eyeBlinkLeft' if side<0 else 'eyeBlinkRight')
  for v in blink.data:v.co.z=(v.co.z+part.location.z-3.015)*.08-(part.location.z-3.015)
 line('Brow',[(x-.16+i*.32/16,-.69,3.235+.025*sin(i/16*pi)) for i in range(17)],.025,chrome)
# Mouth is a genuine tube mesh; morph targets move its corners upwards.
verts=[];faces=[];segments=32;rings=8
for i in range(segments+1):
 t=i/segments;x=(t-.5)*.49;y=-.701+.045*(x/.245)**2;z=2.58
 for j in range(rings):
  a=2*pi*j/rings;verts.append((x,y+.018*cos(a),z+.018*sin(a)))
for i in range(segments):
 for j in range(rings):a=i*rings+j;b=i*rings+(j+1)%rings;faces.append((a,b,b+rings,a+rings))
mesh=bpy.data.meshes.new('Smile geometry');mesh.from_pydata(verts,[],faces);mesh.update();mouth=bpy.data.objects.new('Expression mouth',mesh);bpy.context.collection.objects.link(mouth);finish(mouth,'Expression mouth',mint)
mouth.shape_key_add(name='Basis')
for name,side in [('mouthSmileLeft',-1),('mouthSmileRight',1)]:
 key=mouth.shape_key_add(name=name)
 for v in key.data:
  u=v.co.x/.245
  if u*side>0:v.co.z+=.135*(abs(u)**1.7);v.co.y-=.008*abs(u)
badge('Forehead insignia',(0,-.668,3.30),.19,gold)
# Proper glTF armature with rigid weights; mouth and eyes carry blendshapes.
bpy.ops.object.select_all(action='DESELECT');arm=bpy.data.armatures.new('HaniHoosh Rig');rig=bpy.data.objects.new('HaniHoosh Rig',arm);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for name,head,tail,parent in [('Root',(0,0,0),(0,0,1),None),('Head',(0,0,2.1),(0,0,3.3),'Root'),('Eye_L',(-.265,-.72,3.015),(-.265,-.92,3.015),'Head'),('Eye_R',(.265,-.72,3.015),(.265,-.92,3.015),'Head')]:
 b=arm.edit_bones.new(name);b.head=head;b.tail=tail
 if parent:b.parent=arm.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT')
for o,bone in objects:
 vg=o.vertex_groups.new(name=bone);vg.add(list(range(len(o.data.vertices))),1,'REPLACE');mod=o.modifiers.new('Rigid mechanical rig','ARMATURE');mod.object=rig;o.parent=rig
# Merge static geometry to reduce mobile draw calls.
for bone in ['Root','Head']:
 parts=[o for o,b in objects if b==bone and not o.data.shape_keys]
 bpy.ops.object.select_all(action='DESELECT')
 for o in parts:o.select_set(True)
 bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();parts[0].name=bone+' mechanical surface'
# Attribution is embedded in glTF extras as well as bundled license.
rig['license']='CC0-1.0';rig['creator']='HaniHoosh project / procedural Blender geometry';rig['description']='Original volumetric AI robot bust, rigid Head/Eye rig and mouthSmile blendshapes. No image textures.'
bpy.ops.object.select_all(action='SELECT')
path=os.path.abspath(sys.argv[sys.argv.index('--')+1]) if '--' in sys.argv else os.path.join(os.path.dirname(os.path.abspath(__file__)),'character.glb')
bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',export_yup=True,export_skins=True,export_morph=True,export_extras=True,export_animations=False,export_apply=False,export_texcoords=False)
# The armature parent is identity. Promote skinned mesh nodes to scene roots,
# as recommended by the glTF validator; their world transforms stay identical.
raw=open(path,'rb').read();jl=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+jl]);roots=[]
for i,node in enumerate(doc['nodes']):
 if 'skin' in node:roots.append(i)
for node in doc['nodes']:
 if 'children' in node:node['children']=[i for i in node['children'] if i not in roots]
for scene in doc['scenes']:scene['nodes']+=roots
payload=json.dumps(doc,separators=(',',':')).encode();payload+=b' '*((-len(payload))%4);tail=raw[20+jl:]
open(path,'wb').write(struct.pack('<III',0x46546c67,2,20+len(payload)+len(tail))+struct.pack('<II',len(payload),0x4e4f534a)+payload+tail)
print('MODEL EXPORTED',os.path.getsize(path))
