/* Original volumetric GLB mascot, skinned Head/Eye bones and facial morph targets.
   CC0 model and reproducible Blender source: assets/models/. All dependencies local. */
import * as THREE from './vendor/three.module.js';
import {GLTFLoader} from './vendor/GLTFLoader.js';
const stage=document.getElementById('hh-character');
if(stage?.dataset.model) mountMascot(stage).catch(()=>{
 stage.classList.remove('hh-model-loaded');
 stage.querySelector('.hh-model-status').textContent='نمای ثابت ربات · نمایش سه‌بعدی در این مرورگر در دسترس نیست';
 stage.querySelector('.hh-model-toggle').hidden=true;
 stage.setAttribute('aria-busy','false');
});
async function mountMascot(stage){
 stage.setAttribute('aria-busy','true');
 const status=stage.querySelector('.hh-model-status'),button=stage.querySelector('.hh-model-toggle');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),coarse=matchMedia('(pointer:coarse)');
 let renderer,model,disposed=false;
 const release=()=>{if(disposed)return;disposed=true;model?.traverse(o=>{if(o.isMesh){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose())}});renderer?.dispose();};
 try {
 renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,coarse.matches?1.25:1.65));
 renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(36,1,.05,50);
 scene.add(new THREE.HemisphereLight(0xb5d6ff,0x22214c,2.3));
 const key=new THREE.DirectionalLight(0xc4e2ff,4);key.position.set(-2,4,5);scene.add(key);
 const blue=new THREE.DirectionalLight(0x1775ff,5);blue.position.set(-3,1,1);scene.add(blue);
 const purple=new THREE.DirectionalLight(0x9d46ff,6);purple.position.set(3,2,-2);scene.add(purple);
 const gltf=await new GLTFLoader().loadAsync(stage.dataset.model);model=gltf.scene;scene.add(model);
 const head=model.getObjectByName('Head'),eyes=['Eye_L','Eye_R'].map(n=>model.getObjectByName(n));
 const expressions=[];model.traverse(o=>{if(o.isMesh&&o.morphTargetDictionary)expressions.push(o)});
 if(!head?.isBone||eyes.some(e=>!e?.isBone)||!['mouthSmileLeft','mouthSmileRight'].every(n=>expressions.some(o=>n in o.morphTargetDictionary)))throw Error('Invalid model rig');
 const headBase=head.quaternion.clone(),eyeBase=eyes.map(e=>e.quaternion.clone());
 const box=new THREE.Box3().setFromObject(model),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());
 const q=new THREE.Quaternion(),euler=new THREE.Euler(),axis=new THREE.Vector3(0,1,0);
 // Bones were exported with world-aligned axes. Parent conversion keeps yaw anatomical.
 model.updateMatrixWorld(true);head.parent.getWorldQuaternion(q);axis.applyQuaternion(q.invert()).normalize();
 const morph=(name,value)=>expressions.forEach(o=>{const i=o.morphTargetDictionary[name];if(i!==undefined)o.morphTargetInfluences[i]=value;});
 let frame=0,visible=true,overHead=false,pinned=false,px=0,py=0,yaw=1.27,pitch=0,smile=0,lastTime=0,lastPaint=0,elapsed=0;
 const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
 function pose(){
  head.quaternion.copy(headBase).premultiply(q.setFromAxisAngle(axis,yaw));
  head.quaternion.multiply(q.setFromEuler(euler.set(pitch,0,0)));
  eyes.forEach((eye,i)=>eye.quaternion.copy(eyeBase[i]).multiply(q.setFromEuler(euler.set(py*.025,px*.055,0))));
  morph('mouthSmileLeft',smile);morph('mouthSmileRight',smile);
  const blink=reduced.matches?0:(elapsed%5.2<.2?Math.sin((elapsed%5.2)/.2*Math.PI):0);
  morph('eyeBlinkLeft',blink);morph('eyeBlinkRight',blink);
  blue.intensity=4.7+Math.sin(yaw)*.7;purple.intensity=5.5+Math.cos(yaw)*.6;
  renderer.render(scene,camera);
 }
 function resize(){
  const r=stage.querySelector('.hh-character-image-wrap').getBoundingClientRect();if(!r.width||!r.height)return;
  camera.aspect=r.width/r.height;camera.updateProjectionMatrix();renderer.setSize(r.width,r.height,false);
  const tan=Math.tan(THREE.MathUtils.degToRad(camera.fov/2));
  const distance=Math.max(size.y/(2*tan),size.x/(2*tan*camera.aspect))*1.08;
  camera.position.set(0,center.y,distance);camera.lookAt(center);pose();
 }
 function update(dt){
  const engaging=overHead||pinned;
  const target=engaging?0:coarse.matches?1.12+Math.sin(elapsed*.38)*.14:1.27+px*.15;
  const a=reduced.matches?1:1-Math.exp(-dt*5.8);
  yaw+=(target-yaw)*a;pitch+=((engaging?py*.07:0)-pitch)*a;smile+=((engaging?.85:0)-smile)*a;
 }
 function tick(t){
  frame=0;if(!visible||document.hidden||disposed)return;
  const interval=coarse.matches?1000/30:1000/50;
  if(t-lastPaint>=interval){const dt=Math.min((t-lastTime)/1000||.02,.5);lastTime=t;lastPaint=t;elapsed+=dt;update(dt);pose();}
  if(!reduced.matches)frame=requestAnimationFrame(tick);
 }
 function start(){
  if(disposed||!visible||document.hidden)return;
  if(reduced.matches){cancelAnimationFrame(frame);frame=0;update(1);pose();return;}
  if(!frame){lastTime=performance.now();frame=requestAnimationFrame(tick);}
 }
 function move(event){
  if(coarse.matches||reduced.matches)return;
  const r=stage.querySelector('.hh-character-image-wrap').getBoundingClientRect();px=THREE.MathUtils.clamp((event.clientX-r.left)/r.width*2-1,-1,1);py=THREE.MathUtils.clamp((event.clientY-r.top)/r.height*2-1,-1,1);
  pointer.set(px,-py);raycaster.setFromCamera(pointer,camera);model.updateMatrixWorld(true);
  const inside=event.clientX>=r.left&&event.clientX<=r.right&&event.clientY>=r.top&&event.clientY<=r.bottom;
  const hit=inside?raycaster.intersectObject(model,true)[0]:null;
  overHead=!!hit&&hit.point.y>2.13;start();
 }
 const leave=()=>{overHead=false;px=py=0;start();};
 const toggle=()=>{pinned=!pinned;button.setAttribute('aria-pressed',String(pinned));button.textContent=pinned?'بازگشت به نیم‌رخ':'رو به من بچرخ';start();};
 const visibility=()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else start();};
 const onPreference=()=>{overHead=false;px=py=0;start();};
 const onLoss=event=>{event.preventDefault();cancelAnimationFrame(frame);frame=0;visible=false;stage.classList.remove('hh-model-loaded');status.textContent='نمای ثابت ربات · ارتباط با پردازنده گرافیکی قطع شد';button.hidden=true;};
 renderer.domElement.setAttribute('aria-hidden','true');renderer.domElement.addEventListener('webglcontextlost',onLoss);
 stage.querySelector('.hh-character-image-wrap').append(renderer.domElement);
 button.hidden=false;button.addEventListener('click',toggle);
 window.addEventListener('pointermove',move,{passive:true});stage.addEventListener('pointerleave',leave);
 document.addEventListener('visibilitychange',visibility);reduced.addEventListener('change',onPreference);
 const ro=new ResizeObserver(resize);ro.observe(stage);
 const io=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible)start();else{cancelAnimationFrame(frame);frame=0;}},{threshold:0});io.observe(stage);
 resize();stage.classList.add('hh-model-loaded');stage.setAttribute('aria-busy','false');status.textContent='مدل سه‌بعدی تعاملی · نشانگر را روی سر ببرید';
 start();
 // Integration event also permits independent inspection of the actual rig and morphs.
 stage.dispatchEvent(new CustomEvent('hh:model-ready',{bubbles:true,detail:{model,head,expressions,renderer,camera}}));
 window.addEventListener('pagehide',event=>{if(event.persisted)return;cancelAnimationFrame(frame);window.removeEventListener('pointermove',move);document.removeEventListener('visibilitychange',visibility);reduced.removeEventListener('change',onPreference);ro.disconnect();io.disconnect();release();},{once:false});
 }catch(error){release();throw error;}
}
