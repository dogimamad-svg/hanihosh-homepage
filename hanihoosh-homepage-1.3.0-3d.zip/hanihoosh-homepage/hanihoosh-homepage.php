<?php
/**
 * Plugin Name: HaniHoosh Cinematic Homepage
 * Description: صفحه اصلی اختصاصی هانی‌هوش سازگار با وردپرس فارسی و قالب Astra؛ شامل بخش‌های سینمایی، حرکت کارت‌ها و مدل واقعی GLB با مفصل سر و لبخند.
 * Version: 1.3.0
 * Author: HaniHoosh
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: hanihoosh-home
 */
if (!defined('ABSPATH')) { exit; }

define('HH_HOME_PATH', plugin_dir_path(__FILE__));
define('HH_HOME_URL', plugin_dir_url(__FILE__));

function hh_is_home_target() {
    if (is_admin() || wp_doing_ajax() || is_feed() || is_embed() || is_preview()) return false;
    return is_front_page() && is_page() && (int) get_option('page_on_front') === (int) get_queried_object_id();
}

add_filter('template_include', function($template) {
    if (hh_is_home_target()) {
        $custom = HH_HOME_PATH . 'templates/homepage.php';
        if (is_readable($custom)) return $custom;
    }
    return $template;
}, 99);

add_action('wp_enqueue_scripts', function() {
    if (!hh_is_home_target()) return;
    wp_enqueue_style('hh-home', HH_HOME_URL . 'assets/home.css', [], '1.3.0');
    wp_enqueue_script('hh-home', HH_HOME_URL . 'assets/home.js', [], '1.3.0', true);
    if (is_readable(HH_HOME_PATH . 'assets/models/character.glb')) {
        wp_enqueue_script('hh-home-webgl', HH_HOME_URL . 'assets/portrait-webgl.js', [], '1.3.0', true);
    }
}, 99);

add_filter('body_class', function($classes) {
    if (hh_is_home_target()) $classes[] = 'hh-home-active';
    return $classes;
});

add_action('admin_notices', function() {
    if (!current_user_can('manage_options') || !is_plugin_active(plugin_basename(__FILE__))) return;
    $key = 'hh_home_notice_130_dismissed';
    if (get_user_meta(get_current_user_id(), $key, true)) return;
    $url = wp_nonce_url(admin_url('admin-post.php?action=hh_dismiss_notice'), 'hh_notice');
    echo '<div class="notice notice-success is-dismissible"><p><strong>هانی‌هوش:</strong> نسخه ۱.۳ با مدل واقعی سه‌بعدی ربات، چرخش مفصل سر و لبخند فعال است. صفحه اول سایت را باز کنید. در صورت نیاز به بازگشت به نمایش قبلی، افزونه را غیرفعال کنید. <a href="'.esc_url($url).'">این راهنما را پنهان کن</a></p></div>';
});
add_action('admin_post_hh_dismiss_notice', function() {
    if (!current_user_can('manage_options')) wp_die('Access denied');
    check_admin_referer('hh_notice');
    update_user_meta(get_current_user_id(), 'hh_home_notice_130_dismissed', 1);
    wp_safe_redirect(admin_url('plugins.php')); exit;
});

add_filter('script_loader_tag', function($tag, $handle) {
    if ($handle === 'hh-home-webgl') {
        $tag = preg_replace('/\s+type=([\"\']).*?\1/', '', $tag);
        return str_replace('<script ', '<script type="module" ', $tag);
    }
    return $tag;
}, 10, 2);
