<?php
if (!defined('ABSPATH')) exit;
$asset = static function($name) { return esc_url(HH_HOME_URL . 'assets/' . $name); };
$brand = 'هانی‌هوش';
?><!doctype html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#080B16">
<meta name="description" content="هانی‌هوش؛ آموزش کاربردی هوش مصنوعی، ساخت عکس و ویدیو، ابزارهای خلاقانه و راهکارهای کسب‌وکار دیجیتال.">
<?php if (!current_theme_supports('title-tag')): ?><title><?php echo esc_html($brand); ?></title><?php endif; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="hh-skip" href="#hh-main">رفتن به محتوای اصلی</a>
<div class="hh-site" id="top">
  <div class="hh-stars" aria-hidden="true"></div>
  <header class="hh-header">
    <div class="hh-container hh-header-inner">
      <a class="hh-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="هانی هوش - صفحه اصلی"><img class="hh-logo" src="<?php echo $asset('brand-study.svg'); ?>" alt="" width="60" height="60"><span>هانی<span class="hh-gradient-text">‌هوش</span></span></a>
      <button class="hh-menu-toggle" type="button" aria-label="بازکردن فهرست" aria-controls="hh-nav" aria-expanded="false"><span></span><span></span><span></span></button>
      <nav class="hh-nav" id="hh-nav" aria-label="فهرست اصلی">
        <a href="#top" class="hh-active">صفحه اصلی</a><a href="#hh-courses">دوره‌ها</a><a href="#hh-services">خدمات</a><a href="#hh-work">نمونه‌کارها</a><a href="#hh-roadmap">مسیر یادگیری</a><a href="#hh-faq">سؤالات متداول</a><a href="#hh-contact">تماس با ما</a>
      </nav>
      <a href="#hh-courses" class="hh-gold-btn hh-top-cta">شروع یادگیری <span aria-hidden="true">←</span></a>
    </div>
  </header>
  <main id="hh-main">
    <section class="hh-hero" aria-labelledby="hh-hero-title">
      <div class="hh-hero-glow" aria-hidden="true"></div>
      <div class="hh-container hh-hero-layout">
        <div class="hh-hero-copy hh-reveal" id="hh-about">
          <div class="hh-eyebrow"><span class="hh-pulse"></span> آکادمی و راهکارهای نوین هوش مصنوعی</div>
          <div class="hh-hologram" aria-hidden="true"><img src="<?php echo $asset('brand-study.svg'); ?>" alt="" width="220" height="200"></div>
          <h1 id="hh-hero-title"><span class="hh-title-brand">هانی‌هوش</span><br>آموزش و راهکارهای <span class="hh-gradient-text">هوش مصنوعی</span></h1>
          <p>از یادگیری ابزارهای AI تا تولید محتوا، ساخت ویدیو و راه‌اندازی کسب‌وکار دیجیتال؛ ساده، کاربردی و پروژه‌محور.</p>
          <div class="hh-hero-actions"><a class="hh-gold-btn" href="#hh-courses">مشاهده دوره‌ها <span aria-hidden="true">◀</span></a><a href="#hh-about" class="hh-outline-btn">درباره هانی‌هوش <span aria-hidden="true">↗</span></a></div>
        </div>
        <div class="hh-character-stage" id="hh-character" data-model="<?php echo is_readable(HH_HOME_PATH . 'assets/models/character.glb') ? $asset('models/character.glb') : ''; ?>" role="group" aria-busy="false" aria-label="ربات سه‌بعدی هانی‌هوش با چرخش سر و لبخند">
          <div class="hh-character-halo" aria-hidden="true"></div>
          <div class="hh-character-image-wrap"><img src="<?php echo $asset('robot-fallback.png'); ?>" alt="نمای ثابت مدل سه‌بعدی ربات هانی‌هوش برای مرورگرهای بدون WebGL" class="hh-character-profile" fetchpriority="high" width="700" height="700"></div>
          <p class="hh-model-status" role="status">نمای ثابت ربات؛ نمایش تعاملی پس از بارگذاری فعال می‌شود</p><button type="button" class="hh-model-toggle" aria-pressed="false" hidden>رو به من بچرخ</button>
        </div>
      </div>
      <div class="hh-hero-side"><a href="#hh-courses"><span class="hh-circle-icon" aria-hidden="true">✦</span><span><strong>آموزش‌های کاربردی</strong><small>قدم‌به‌قدم و پروژه‌محور</small></span></a><a href="#hh-services"><span class="hh-circle-icon" aria-hidden="true">⚙</span><span><strong>ابزارهای به‌روز</strong><small>ChatGPT، Gemini و Flow</small></span></a><a href="#hh-work"><span class="hh-circle-icon" aria-hidden="true">▧</span><span><strong>نمونه‌کارهای خلاقانه</strong><small>نگاهی به دنیای تصویر و ویدیو</small></span></a><a href="#hh-faq"><span class="hh-circle-icon" aria-hidden="true">◎</span><span><strong>راهنمای شروع</strong><small>پاسخ به پرسش‌های یادگیری</small></span></a></div>
    </section>

    <section class="hh-container hh-quick-services" id="hh-services" aria-label="زمینه‌های آموزشی و خدماتی">
      <?php $q=[['✺','آموزش ChatGPT','از مقدماتی تا کاربردی','#hh-courses'],['✧','آموزش Gemini','کاربردهای واقعی و روزمره','#hh-courses'],['▶','آموزش Google Flow','ساخت ویدیو با هوش مصنوعی','#hh-courses'],['▣','تولید محتوای AI','عکس، ویدیو و متن','#hh-about'],['⚙','ابزارها و اتوماسیون','راهکارهای هوشمند','#hh-contact']]; foreach($q as $item): ?><a class="hh-quick-card hh-tilt hh-reveal" href="<?php echo esc_attr($item[3]); ?>"><span class="hh-quick-icon" aria-hidden="true"><?php echo esc_html($item[0]); ?></span><strong><?php echo esc_html($item[1]); ?></strong><small><?php echo esc_html($item[2]); ?></small></a><?php endforeach; ?>
    </section>



    <section class="hh-section hh-container hh-courses-wrap" id="hh-courses">
      <div class="hh-section-title hh-reveal"><span class="hh-kicker">یادگیری قدم‌به‌قدم</span><h2>دوره‌های آموزشی هانی‌هوش</h2><p>آموزش ابزارهای کاربردی و پروژه‌محور برای ورود عملی به دنیای هوش مصنوعی</p></div>
      <p class="hh-content-status">پیش‌نمایش سرفصل‌ها · ثبت‌نام و محتوای آموزشی هنوز منتشر نشده‌اند.</p><div class="hh-course-grid">
        <?php $courses=[['course-chatgpt.jpg','آموزش جامع ChatGPT','پرامپت‌نویسی و کارهای روزمره'],['course-gemini.jpg','آموزش جامع Gemini','ابزارهای گوگل و ایده‌پردازی'],['course-flow.jpg','آموزش Google Flow','ساخت ویدیو و روایت تصویری'],['course-creative.jpg','تولید محتوا با AI','ایده، تصویر، ویدیو و سناریو']]; foreach($courses as $course): ?><article class="hh-course-card hh-tilt hh-reveal"><div class="hh-course-image"><img src="<?php echo $asset($course[0]); ?>" alt="نمای مفهومی <?php echo esc_attr($course[1]); ?>" loading="lazy"></div><div class="hh-course-content"><h3><?php echo esc_html($course[1]); ?></h3><p><?php echo esc_html($course[2]); ?></p><a href="#hh-contact" class="hh-gold-btn hh-btn-small">وضعیت انتشار <span aria-hidden="true">←</span></a></div></article><?php endforeach; ?>
        <article class="hh-free-card hh-reveal" id="hh-free"><div class="hh-gift" aria-hidden="true">🎁</div><span class="hh-kicker">آموزش رایگان</span><h3>از همین امروز شروع کن</h3><p>مجموعه‌ای از موضوعات کاربردی هوش مصنوعی برای شروع یادگیری، بدون نیاز به تجربه قبلی.</p><a class="hh-gold-btn" href="#hh-contact">وضعیت انتشار آموزش‌ها ←</a><span class="hh-free-spark" aria-hidden="true">✦</span></article>
      </div>
      <div class="hh-metrics hh-reveal" aria-label="آمار در انتظار تأیید"><div><strong>—</strong><span>دانشجویان</span></div><div><strong>—</strong><span>دوره‌های منتشرشده</span></div><div><strong>—</strong><span>پروژه‌های تأییدشده</span></div><div><strong>—</strong><span>رضایت کاربران</span></div></div><p class="hh-content-status">جایگاه آمار واقعی · داده‌ای هنوز تأیید نشده است.</p>
    </section>

    <section class="hh-section hh-container" id="hh-work"><div class="hh-section-title hh-reveal"><span class="hh-kicker">خلاقیت در عمل</span><h2>نمونه‌کارها</h2><p>تصاویر مفهومی برای نمایش سبک پروژه‌ها؛ به‌زودی با نمونه‌کارهای واقعی جایگزین می‌شوند.</p></div>
      <div class="hh-work-grid">
        <?php $works=[['portfolio-parrot.jpg','ساخت ویدیو با AI'],['portfolio-building.jpg','تولید تصویر با AI'],['portfolio-car.jpg','تیزر تبلیغاتی'],['portfolio-city.jpg','ویدیوهای اجتماعی'],['portfolio-fantasy.jpg','انیمیشن و موشن گرافیک']];foreach($works as $item): ?><div class="hh-work-card hh-reveal"><img loading="lazy" src="<?php echo $asset($item[0]); ?>" alt="تصویر مفهومی <?php echo esc_attr($item[1]); ?>"><span><?php echo esc_html($item[1]); ?></span><small>تصویر نمایشی</small></div><?php endforeach; ?>
      </div>
    </section>

    <section class="hh-section hh-container" id="hh-roadmap"><div class="hh-section-title hh-reveal"><span class="hh-kicker">مسیر رشد</span><h2>مسیر یادگیری در هانی‌هوش</h2><p>چهار قدم روشن؛ از آشنایی با ابزار تا ساخت پروژه واقعی</p></div>
      <div class="hh-steps"><div class="hh-step hh-reveal"><b>۱</b><div><h3>آشنایی با ابزارها</h3><p>معرفی و شناخت ابزارهای AI</p></div></div><div class="hh-step hh-reveal"><b>۲</b><div><h3>آموزش پایه</h3><p>یادگیری ساده و پروژه‌محور</p></div></div><div class="hh-step hh-reveal"><b>۳</b><div><h3>تمرین و اجرا</h3><p>انجام تمرین‌ها و پروژه‌های واقعی</p></div></div><div class="hh-step hh-reveal"><b>۴</b><div><h3>ورود به بازار کار</h3><p>توسعه مهارت و ساخت نمونه‌کار</p></div></div></div>
    </section>

    <section class="hh-section hh-container hh-testimonials"><div class="hh-section-title hh-reveal"><span class="hh-kicker">تجربه یادگیرندگان</span><h2>نظرات هنرجویان</h2><p>این بخش پس از دریافت و تأیید نظرات واقعی تکمیل می‌شود.</p></div><div class="hh-placeholder hh-reveal"><span aria-hidden="true">✧</span> جایگاه نظرات واقعی و تأییدشده هنرجویان</div></section>

    <section class="hh-section hh-container hh-bottom" id="hh-faq"><div class="hh-faq"><div class="hh-section-title hh-reveal"><h2>سؤالات متداول</h2></div><details class="hh-reveal"><summary>آیا آموزش‌ها برای مبتدی‌ها مناسب هستند؟</summary><p>مسیر پیشنهادی از مفاهیم ابتدایی شروع می‌شود؛ جزئیات هر دوره پس از انتشار مشخص خواهد شد.</p></details><details class="hh-reveal"><summary>برای یادگیری هوش مصنوعی باید برنامه‌نویسی بلد باشم؟</summary><p>برای شروع بسیاری از ابزارهای معرفی‌شده نیازی به برنامه‌نویسی نیست.</p></details><details class="hh-reveal"><summary>چه ابزارهایی در هانی‌هوش معرفی می‌شوند؟</summary><p>ابزارهایی مانند ChatGPT، Gemini، Google Flow و ابزارهای تصویرسازی و اتوماسیون.</p></details><details class="hh-reveal"><summary>چطور از انتشار آموزش‌های جدید باخبر شوم؟</summary><p>این بخش پس از ثبت راه‌های رسمی ارتباطی و شبکه‌های اجتماعی هانی‌هوش تکمیل می‌شود.</p></details></div>
      <div class="hh-final-cta hh-reveal"><img src="<?php echo $asset('cyborg-front.jpg'); ?>" loading="lazy" alt="چهره آینده‌نگر نیمه‌انسان و نیمه‌ربات"><div><span class="hh-kicker">شروع مسیر تازه</span><h2>آینده با هوش مصنوعی فرصت‌های جدیدی داره</h2><p>همین حالا یادگیری رو شروع کن، یک قدم جلوتر باش.</p><a href="#hh-courses" class="hh-gold-btn">شروع یادگیری ←</a></div></div>
    </section>
  </main>
  <footer class="hh-footer hh-reveal" id="hh-contact"><div class="hh-container hh-footer-grid"><div><a class="hh-brand" href="#top"><img class="hh-logo" src="<?php echo $asset('brand-study.svg'); ?>" alt="" width="60" height="60"> هانی‌هوش</a><p>آموزش و راهکارهای خلاقانه هوش مصنوعی؛ از ایده تا اجرا.</p></div><div><h3>دسترسی سریع</h3><a href="#top">خانه</a><a href="#hh-courses">دوره‌ها</a><a href="#hh-work">نمونه‌کارها</a></div><div><h3>بخش‌های سایت</h3><a href="#hh-services">خدمات</a><a href="#hh-roadmap">مسیر یادگیری</a><a href="#hh-faq">سؤالات متداول</a></div><div><h3>ارتباط با ما</h3><p>اطلاعات تماس رسمی و لینک شبکه‌های اجتماعی پس از تأیید اضافه می‌شود.</p><a href="<?php echo esc_url(home_url('/wp-admin/')); ?>" class="hh-admin-link">ورود مدیر سایت</a></div></div><div class="hh-footer-bottom hh-container">© <?php echo esc_html(wp_date('Y')); ?> هانی‌هوش · تمامی حقوق محفوظ است. <span>طراحی اختصاصی برای وردپرس</span></div></footer>
  <a class="hh-backtotop" href="#top" aria-label="بازگشت به بالا">↑</a>
</div>
<?php wp_footer(); ?>
</body></html>
